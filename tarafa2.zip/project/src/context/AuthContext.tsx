import React, { createContext, useContext, useState } from 'react';
import { User, AuthContextType } from '../types';

const AuthContext = createContext<AuthContextType | null>(null);

const VALID_CREDENTIALS = {
  manager: { username: 'gerente', password: 'admin123' },
  employee: { username: 'funcionario', password: 'func123' }
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  const login = async (username: string, password: string) => {
    if (username === VALID_CREDENTIALS.manager.username && 
        password === VALID_CREDENTIALS.manager.password) {
      setUser({ id: '1', username, role: 'manager' });
    } else if (username === VALID_CREDENTIALS.employee.username && 
               password === VALID_CREDENTIALS.employee.password) {
      setUser({ id: '2', username, role: 'employee' });
    } else {
      throw new Error('Credenciais inválidas');
    }
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth deve ser usado dentro de um AuthProvider');
  }
  return context;
};