import React, { useState, useEffect } from 'react';
import { Task, UrgencyLevel } from '../types';
import { useEmployees } from '../context/EmployeeContext';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { CheckCircle, AlertCircle, Trash2, Edit2, Clock, Search, RefreshCw } from 'lucide-react';

interface TaskListProps {
  tasks: Task[];
  onUpdateTask: (taskId: string, completedQuantity: number) => void;
  onNotifyComplete: (taskId: string) => void;
  onDeleteTask?: (taskId: string) => void;
  onUpdateQuantity?: (taskId: string, newQuantity: number) => void;
}

const ITEMS_PER_PAGE = 5;

export default function TaskList({ 
  tasks, 
  onUpdateTask, 
  onNotifyComplete,
  onDeleteTask,
  onUpdateQuantity 
}: TaskListProps) {
  const { employees } = useEmployees();
  const { user } = useAuth();
  const { addNotification } = useNotifications();
  const [editingTask, setEditingTask] = useState<string | null>(null);
  const [newQuantity, setNewQuantity] = useState<number>(0);
  const [reportMessage, setReportMessage] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'in-progress' | 'completed'>('all');
  const [urgencyFilter, setUrgencyFilter] = useState<'all' | UrgencyLevel>('all');
  const [autoRefresh, setAutoRefresh] = useState(true);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (autoRefresh) {
      interval = setInterval(() => {
        // Force re-render
        setCurrentPage(current => current);
      }, 30000); // Refresh every 30 seconds
    }
    return () => clearInterval(interval);
  }, [autoRefresh]);

  const getEmployeeColor = (employeeId: string | null) => {
    const employee = employees.find(emp => emp.id === employeeId);
    return employee?.color || '#CBD5E0';
  };

  const getUrgencyColor = (urgency: UrgencyLevel) => {
    switch (urgency) {
      case 'very-urgent':
        return 'bg-red-100 text-red-800';
      case 'urgent':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-green-100 text-green-800';
    }
  };

  const getUrgencyLabel = (urgency: UrgencyLevel) => {
    switch (urgency) {
      case 'very-urgent':
        return 'Muito Urgente (30min)';
      case 'urgent':
        return 'Urgente (1h)';
      default:
        return 'Normal';
    }
  };

  const formatDeadline = (deadline: string) => {
    return new Date(deadline).toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getRemainingTime = (deadline: string) => {
    const now = new Date();
    const deadlineDate = new Date(deadline);
    const diff = deadlineDate.getTime() - now.getTime();
    
    if (diff < 0) return 'Atrasado';
    
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    return `${hours}h ${minutes}min`;
  };

  const handleReport = (taskId: string) => {
    if (reportMessage.trim()) {
      addNotification({
        message: `Relatório para tarefa ${taskId}: ${reportMessage}`,
        createdAt: new Date().toISOString(),
        taskId
      });
      setReportMessage('');
    }
  };

  const handleQuantityUpdate = (taskId: string) => {
    if (onUpdateQuantity && newQuantity > 0) {
      onUpdateQuantity(taskId, newQuantity);
      setEditingTask(null);
      setNewQuantity(0);
    }
  };

  const filteredTasks = tasks
    .filter(task => {
      const matchesSearch = task.productName.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === 'all' || task.status === statusFilter;
      const matchesUrgency = urgencyFilter === 'all' || task.urgency === urgencyFilter;
      const matchesUser = user?.role === 'employee' ? task.assignedTo === user.id : true;
      return matchesSearch && matchesStatus && matchesUrgency && matchesUser;
    })
    .sort((a, b) => {
      const urgencyOrder = { 'very-urgent': 0, 'urgent': 1, 'normal': 2 };
      if (urgencyOrder[a.urgency] !== urgencyOrder[b.urgency]) {
        return urgencyOrder[a.urgency] - urgencyOrder[b.urgency];
      }
      return new Date(a.deadline).getTime() - new Date(b.deadline).getTime();
    });

  const totalPages = Math.ceil(filteredTasks.length / ITEMS_PER_PAGE);
  const paginatedTasks = filteredTasks.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  return (
    <div className="mt-8">
      <div className="mb-6 space-y-4">
        <div className="flex flex-wrap gap-4 items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="relative">
              <Search className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar tarefas..."
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <select
              className="border border-gray-300 rounded-md px-3 py-2 focus:ring-blue-500 focus:border-blue-500"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
            >
              <option value="all">Todos os Status</option>
              <option value="pending">Pendente</option>
              <option value="in-progress">Em Progresso</option>
              <option value="completed">Completo</option>
            </select>
            <select
              className="border border-gray-300 rounded-md px-3 py-2 focus:ring-blue-500 focus:border-blue-500"
              value={urgencyFilter}
              onChange={(e) => setUrgencyFilter(e.target.value as any)}
            >
              <option value="all">Todas as Urgências</option>
              <option value="very-urgent">Muito Urgente</option>
              <option value="urgent">Urgente</option>
              <option value="normal">Normal</option>
            </select>
          </div>
          <button
            className={`flex items-center space-x-2 px-4 py-2 rounded-md ${
              autoRefresh ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'
            }`}
            onClick={() => setAutoRefresh(!autoRefresh)}
          >
            <RefreshCw className={`h-4 w-4 ${autoRefresh ? 'animate-spin' : ''}`} />
            <span>Atualização Automática</span>
          </button>
        </div>
      </div>

      <div className="flex flex-col">
        <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
          <div className="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
            <div className="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Produto
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Funcionário
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Quantidade
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Prazo
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Urgência
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Ações
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {paginatedTasks.map((task) => {
                    const employee = employees.find(emp => emp.id === task.assignedTo);
                    const isEditing = editingTask === task.id;
                    const remainingTime = getRemainingTime(task.deadline);
                    
                    return (
                      <tr key={task.id} style={{ backgroundColor: `${getEmployeeColor(task.assignedTo)}05` }}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">{task.productName}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div
                              className="w-3 h-3 rounded-full mr-2"
                              style={{ backgroundColor: getEmployeeColor(task.assignedTo) }}
                            />
                            <span className="text-sm text-gray-900">{employee?.name || 'Não atribuído'}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {isEditing && user?.role === 'manager' ? (
                            <div className="flex items-center space-x-2">
                              <input
                                type="number"
                                className="w-20 rounded border-gray-300"
                                value={newQuantity}
                                onChange={(e) => setNewQuantity(Number(e.target.value))}
                                min="1"
                              />
                              <button
                                onClick={() => handleQuantityUpdate(task.id)}
                                className="text-blue-600 hover:text-blue-800"
                              >
                                <CheckCircle className="h-4 w-4" />
                              </button>
                            </div>
                          ) : (
                            <div className="text-sm text-gray-900">
                              {task.completedQuantity} / {task.requiredQuantity}
                              {user?.role === 'manager' && (
                                <button
                                  onClick={() => {
                                    setEditingTask(task.id);
                                    setNewQuantity(task.requiredQuantity);
                                  }}
                                  className="ml-2 text-blue-600 hover:text-blue-800"
                                >
                                  <Edit2 className="h-4 w-4" />
                                </button>
                              )}
                            </div>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <Clock className="h-4 w-4 mr-1 text-gray-500" />
                            <div className="text-sm text-gray-900">
                              <div>{formatDeadline(task.deadline)}</div>
                              <div className="text-xs text-gray-500">
                                Restante: {remainingTime}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getUrgencyColor(task.urgency)}`}>
                            {getUrgencyLabel(task.urgency)}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                            ${task.status === 'completed' ? 'bg-green-100 text-green-800' : 
                              task.status === 'in-progress' ? 'bg-yellow-100 text-yellow-800' : 
                              'bg-gray-100 text-gray-800'}`}>
                            {task.status === 'completed' ? 'Completo' : 
                             task.status === 'in-progress' ? 'Em Progresso' : 
                             'Pendente'}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <div className="flex items-center space-x-2">
                            {user?.role === 'employee' && task.assignedTo === user.id && (
                              <>
                                <input
                                  type="number"
                                  className="w-20 rounded border-gray-300"
                                  placeholder="Qtd"
                                  min="0"
                                  max={task.requiredQuantity}
                                  onChange={(e) => onUpdateTask(task.id, Number(e.target.value))}
                                />
                                <div className="flex items-center space-x-2">
                                  <input
                                    type="text"
                                    className="w-40 rounded border-gray-300"
                                    placeholder="Reportar problema..."
                                    value={reportMessage}
                                    onChange={(e) => setReportMessage(e.target.value)}
                                  />
                                  <button
                                    onClick={() => handleReport(task.id)}
                                    className="inline-flex items-center px-2 py-1 border border-transparent text-xs font-medium rounded text-white bg-yellow-600 hover:bg-yellow-700"
                                  >
                                    <AlertCircle className="h-4 w-4 mr-1" />
                                    Reportar
                                  </button>
                                </div>
                              </>
                            )}
                            {user?.role === 'manager' && (
                              <button
                                onClick={() => onDeleteTask?.(task.id)}
                                className="text-red-600 hover:text-red-800"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {totalPages > 1 && (
        <div className="mt-4 flex justify-center">
          <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">
            <button
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
            >
              Anterior
            </button>
            {[...Array(totalPages)].map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentPage(i + 1)}
                className={`relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium ${
                  currentPage === i + 1
                    ? 'z-10 bg-blue-50 border-blue-500 text-blue-600'
                    : 'bg-white text-gray-500 hover:bg-gray-50'
                }`}
              >
                {i + 1}
              </button>
            ))}
            <button
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
            >
              Próxima
            </button>
          </nav>
        </div>
      )}
    </div>
  );
}