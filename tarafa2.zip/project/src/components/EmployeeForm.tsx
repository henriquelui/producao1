import React, { useState } from 'react';
import { useEmployees } from '../context/EmployeeContext';
import { UserPlus } from 'lucide-react';

export default function EmployeeForm() {
  const [name, setName] = useState('');
  const [color, setColor] = useState('#000000');
  const { addEmployee } = useEmployees();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && color) {
      addEmployee({
        name,
        color,
        active: true,
      });
      setName('');
      setColor('#000000');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow">
      <div className="flex items-center mb-4">
        <UserPlus className="h-5 w-5 text-blue-500 mr-2" />
        <h2 className="text-lg font-semibold">Novo Funcionário</h2>
      </div>
      <div className="space-y-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700">
            Nome
          </label>
          <input
            type="text"
            id="name"
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>
        <div>
          <label htmlFor="color" className="block text-sm font-medium text-gray-700">
            Cor de Identificação
          </label>
          <input
            type="color"
            id="color"
            required
            className="mt-1 block w-full h-10 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            value={color}
            onChange={(e) => setColor(e.target.value)}
          />
        </div>
        <button
          type="submit"
          className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          Adicionar Funcionário
        </button>
      </div>
    </form>
  );
}