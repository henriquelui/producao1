import React, { useState } from 'react';
import { Task } from '../types';
import { Download, Calendar } from 'lucide-react';
import jsPDF from 'jspdf';
import 'jspdf-autotable';

interface TaskAnalyticsProps {
  tasks: Task[];
  employees: any[];
}

export default function TaskAnalytics({ tasks, employees }: TaskAnalyticsProps) {
  const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().slice(0, 7));
  const [selectedEmployee, setSelectedEmployee] = useState('all');

  const filteredTasks = tasks.filter(task => {
    const taskDate = new Date(task.createdAt).toISOString().slice(0, 7);
    const employeeMatch = selectedEmployee === 'all' || task.assignedTo === selectedEmployee;
    return taskDate === selectedMonth && employeeMatch && task.status === 'completed';
  });

  const generatePDF = () => {
    const doc = new jsPDF();
    const employee = selectedEmployee === 'all' 
      ? 'Todos os Funcionários' 
      : employees.find(emp => emp.id === selectedEmployee)?.name;
    const monthYear = new Date(selectedMonth).toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });

    doc.text(`Relatório de Produção - ${monthYear}`, 14, 15);
    doc.text(`Funcionário: ${employee}`, 14, 25);

    const tableData = filteredTasks.map(task => [
      task.productName,
      task.requiredQuantity.toString(),
      task.completedQuantity.toString(),
      new Date(task.completedAt || task.updatedAt).toLocaleDateString('pt-BR'),
      task.urgency === 'very-urgent' ? 'Muito Urgente' : task.urgency === 'urgent' ? 'Urgente' : 'Normal'
    ]);

    (doc as any).autoTable({
      head: [['Produto', 'Qtd. Requerida', 'Qtd. Completada', 'Data Conclusão', 'Urgência']],
      body: tableData,
      startY: 35,
    });

    doc.save(`relatorio-producao-${monthYear}.pdf`);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold">Análise de Produção</h2>
        <button
          onClick={generatePDF}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
        >
          <Download className="h-4 w-4 mr-2" />
          Exportar PDF
        </button>
      </div>

      <div className="flex flex-wrap gap-4 mb-6">
        <div className="flex items-center space-x-2">
          <Calendar className="h-5 w-5 text-gray-400" />
          <input
            type="month"
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="border border-gray-300 rounded-md px-3 py-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        <select
          value={selectedEmployee}
          onChange={(e) => setSelectedEmployee(e.target.value)}
          className="border border-gray-300 rounded-md px-3 py-2 focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="all">Todos os Funcionários</option>
          {employees.map(employee => (
            <option key={employee.id} value={employee.id}>
              {employee.name}
            </option>
          ))}
        </select>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Produto
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Quantidade
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Data Conclusão
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Urgência
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredTasks.map((task) => (
              <tr key={task.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {task.productName}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {task.completedQuantity} / {task.requiredQuantity}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {new Date(task.completedAt || task.updatedAt).toLocaleDateString('pt-BR')}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                    task.urgency === 'very-urgent' ? 'bg-red-100 text-red-800' :
                    task.urgency === 'urgent' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-green-100 text-green-800'
                  }`}>
                    {task.urgency === 'very-urgent' ? 'Muito Urgente' :
                     task.urgency === 'urgent' ? 'Urgente' : 'Normal'}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}