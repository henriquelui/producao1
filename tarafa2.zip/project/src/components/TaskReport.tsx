import React from 'react';
import * as Tooltip from '@radix-ui/react-tooltip';
import { AlertCircle } from 'lucide-react';
import { useNotifications } from '../context/NotificationContext';

interface TaskReportProps {
  taskId: string;
  reportMessage: string;
  setReportMessage: (message: string) => void;
  onReport: (taskId: string) => void;
}

export default function TaskReport({ taskId, reportMessage, setReportMessage, onReport }: TaskReportProps) {
  const { notifications } = useNotifications();
  const taskNotifications = notifications.filter(n => n.taskId === taskId && !n.read);

  return (
    <div className="flex items-center space-x-2">
      <input
        type="text"
        className="w-40 rounded border-gray-300"
        placeholder="Reportar problema..."
        value={reportMessage}
        onChange={(e) => setReportMessage(e.target.value)}
      />
      <Tooltip.Provider>
        <Tooltip.Root>
          <Tooltip.Trigger asChild>
            <button
              onClick={() => onReport(taskId)}
              className="inline-flex items-center px-2 py-1 border border-transparent text-xs font-medium rounded text-white bg-yellow-600 hover:bg-yellow-700"
            >
              <AlertCircle className={`h-4 w-4 mr-1 ${taskNotifications.length > 0 ? 'animate-pulse' : ''}`} />
              Reportar
            </button>
          </Tooltip.Trigger>
          {taskNotifications.length > 0 && (
            <Tooltip.Portal>
              <Tooltip.Content
                className="bg-white p-2 rounded-lg shadow-lg border border-gray-200 max-w-xs"
                sideOffset={5}
              >
                <div className="text-sm">
                  {taskNotifications.map((notification, index) => (
                    <div key={notification.id} className={index > 0 ? 'mt-2 pt-2 border-t' : ''}>
                      {notification.message}
                    </div>
                  ))}
                </div>
                <Tooltip.Arrow className="fill-white" />
              </Tooltip.Content>
            </Tooltip.Portal>
          )}
        </Tooltip.Root>
      </Tooltip.Provider>
    </div>
  );
}