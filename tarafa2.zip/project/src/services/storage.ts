import { Task, Employee, Notification } from '../types';

const STORAGE_KEYS = {
  TASKS: 'production_system_tasks',
  EMPLOYEES: 'production_system_employees',
  NOTIFICATIONS: 'production_system_notifications',
};

export const storage = {
  getTasks: (): Task[] => {
    const tasks = localStorage.getItem(STORAGE_KEYS.TASKS);
    return tasks ? JSON.parse(tasks) : [];
  },

  saveTasks: (tasks: Task[]) => {
    localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(tasks));
  },

  getEmployees: (): Employee[] => {
    const employees = localStorage.getItem(STORAGE_KEYS.EMPLOYEES);
    return employees ? JSON.parse(employees) : [];
  },

  saveEmployees: (employees: Employee[]) => {
    localStorage.setItem(STORAGE_KEYS.EMPLOYEES, JSON.stringify(employees));
  },

  getNotifications: (): Notification[] => {
    const notifications = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
    return notifications ? JSON.parse(notifications) : [];
  },

  saveNotifications: (notifications: Notification[]) => {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifications));
  },
};