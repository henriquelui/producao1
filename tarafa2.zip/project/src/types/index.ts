export interface User {
  id: string;
  username: string;
  role: 'manager' | 'employee';
  color?: string;
}

export interface Employee {
  id: string;
  name: string;
  color: string;
  active: boolean;
}

export type UrgencyLevel = 'very-urgent' | 'urgent' | 'normal';

export interface Task {
  id: string;
  productName: string;
  requiredQuantity: number;
  completedQuantity: number;
  status: 'pending' | 'in-progress' | 'completed';
  assignedTo: string | null;
  createdAt: string;
  updatedAt: string;
  completedAt?: string;
  notified: boolean;
  deadline: string;
  urgency: UrgencyLevel;
}

export interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
}

export interface NotificationContextType {
  notifications: Notification[];
  addNotification: (notification: Omit<Notification, 'id' | 'read'>) => void;
  markAsRead: (id: string) => void;
}

export interface Notification {
  id: string;
  message: string;
  createdAt: string;
  read: boolean;
  taskId: string;
}