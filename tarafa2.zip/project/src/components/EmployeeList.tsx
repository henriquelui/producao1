import React from 'react';
import { useEmployees } from '../context/EmployeeContext';
import { Users } from 'lucide-react';

export default function EmployeeList() {
  const { employees, toggleEmployeeStatus } = useEmployees();

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <div className="flex items-center mb-4">
        <Users className="h-5 w-5 text-blue-500 mr-2" />
        <h2 className="text-lg font-semibold">Employees</h2>
      </div>
      <div className="space-y-3">
        {employees.map((employee) => (
          <div
            key={employee.id}
            className="flex items-center justify-between p-3 rounded-lg"
            style={{ backgroundColor: `${employee.color}15` }}
          >
            <div className="flex items-center">
              <div
                className="w-3 h-3 rounded-full mr-3"
                style={{ backgroundColor: employee.color }}
              />
              <span className="font-medium">{employee.name}</span>
            </div>
            <button
              onClick={() => toggleEmployeeStatus(employee.id)}
              className={`px-2 py-1 rounded text-xs font-semibold ${
                employee.active
                  ? 'bg-green-100 text-green-800'
                  : 'bg-gray-100 text-gray-800'
              }`}
            >
              {employee.active ? 'Active' : 'Inactive'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}