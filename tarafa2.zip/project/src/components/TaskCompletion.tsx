import React from 'react';
import { CheckCircle } from 'lucide-react';

interface TaskCompletionProps {
  taskId: string;
  requiredQuantity: number;
  completedQuantity: number;
  onUpdateTask: (taskId: string, quantity: number) => void;
}

export default function TaskCompletion({ 
  taskId, 
  requiredQuantity, 
  completedQuantity, 
  onUpdateTask 
}: TaskCompletionProps) {
  const handleComplete = () => {
    if (completedQuantity < requiredQuantity) {
      alert('Por favor, finalize todas as peças antes de completar a tarefa.');
      return;
    }
    onUpdateTask(taskId, requiredQuantity);
  };

  return (
    <div className="flex items-center space-x-2">
      <input
        type="number"
        className="w-20 rounded border-gray-300"
        placeholder="Qtd"
        min="0"
        max={requiredQuantity}
        value={completedQuantity}
        onChange={(e) => onUpdateTask(taskId, Number(e.target.value))}
      />
      <button
        onClick={handleComplete}
        className={`inline-flex items-center px-2 py-1 border border-transparent text-xs font-medium rounded ${
          completedQuantity >= requiredQuantity
            ? 'text-white bg-green-600 hover:bg-green-700'
            : 'text-gray-700 bg-gray-200'
        }`}
      >
        <CheckCircle className="h-4 w-4 mr-1" />
        Finalizar
      </button>
    </div>
  );
}