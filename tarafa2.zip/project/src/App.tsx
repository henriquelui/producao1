import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { EmployeeProvider } from './context/EmployeeContext';
import { NotificationProvider } from './context/NotificationContext';
import LoginForm from './components/LoginForm';
import Navbar from './components/Navbar';
import TaskForm from './components/TaskForm';
import TaskList from './components/TaskList';
import EmployeeList from './components/EmployeeList';
import EmployeeForm from './components/EmployeeForm';
import { Task, UrgencyLevel } from './types';
import { storage } from './services/storage';

function Dashboard() {
  const [tasks, setTasks] = useState<Task[]>(() => {
    return storage.getTasks();
  });
  const { user } = useAuth();

  useEffect(() => {
    storage.saveTasks(tasks);
  }, [tasks]);

  const handleAddTask = (
    productName: string,
    quantity: number,
    assignedTo: string,
    deadline: string,
    urgency: UrgencyLevel
  ) => {
    const newTask: Task = {
      id: Date.now().toString(),
      productName,
      requiredQuantity: quantity,
      completedQuantity: 0,
      status: 'pending',
      assignedTo,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      notified: false,
      deadline,
      urgency,
    };
    setTasks(prev => [...prev, newTask]);
  };

  const handleUpdateTask = (taskId: string, completedQuantity: number) => {
    setTasks(prev => prev.map(task => {
      if (task.id === taskId) {
        const status = completedQuantity >= task.requiredQuantity ? 'completed' : 
                      completedQuantity > 0 ? 'in-progress' : 'pending';
        return {
          ...task,
          completedQuantity,
          status,
          updatedAt: new Date().toISOString(),
        };
      }
      return task;
    }));
  };

  const handleDeleteTask = (taskId: string) => {
    setTasks(prev => prev.filter(task => task.id !== taskId));
  };

  const handleUpdateQuantity = (taskId: string, newQuantity: number) => {
    setTasks(prev => prev.map(task => {
      if (task.id === taskId) {
        return {
          ...task,
          requiredQuantity: newQuantity,
          updatedAt: new Date().toISOString(),
        };
      }
      return task;
    }));
  };

  const handleNotifyComplete = (taskId: string) => {
    setTasks(prev => prev.map(task => 
      task.id === taskId ? { ...task, notified: true } : task
    ));
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {user?.role === 'manager' && (
              <>
                <div className="md:col-span-1">
                  <TaskForm onSubmit={handleAddTask} />
                  <div className="mt-6">
                    <EmployeeList />
                  </div>
                  <div className="mt-6">
                    <EmployeeForm />
                  </div>
                </div>
                <div className="md:col-span-3">
                  <TaskList
                    tasks={tasks}
                    onUpdateTask={handleUpdateTask}
                    onNotifyComplete={handleNotifyComplete}
                    onDeleteTask={handleDeleteTask}
                    onUpdateQuantity={handleUpdateQuantity}
                  />
                </div>
              </>
            )}
            {user?.role === 'employee' && (
              <div className="md:col-span-4">
                <TaskList
                  tasks={tasks}
                  onUpdateTask={handleUpdateTask}
                  onNotifyComplete={handleNotifyComplete}
                />
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <EmployeeProvider>
        <NotificationProvider>
          <AppContent />
        </NotificationProvider>
      </EmployeeProvider>
    </AuthProvider>
  );
}

function AppContent() {
  const { user } = useAuth();
  return user ? <Dashboard /> : <LoginForm />;
}

export default App;