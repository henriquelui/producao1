import React, { createContext, useContext, useState, useEffect } from 'react';
import { Employee } from '../types';
import { storage } from '../services/storage';

interface EmployeeContextType {
  employees: Employee[];
  addEmployee: (employee: Omit<Employee, 'id'>) => void;
  removeEmployee: (id: string) => void;
  toggleEmployeeStatus: (id: string) => void;
}

const defaultEmployees: Employee[] = [
  { id: '1', name: 'João Silva', color: '#FF5733', active: true },
  { id: '2', name: 'Maria Santos', color: '#33FF57', active: true },
  { id: '3', name: 'Pedro Oliveira', color: '#3357FF', active: true },
  { id: '4', name: 'Ana Costa', color: '#FF33F6', active: true },
  { id: '5', name: 'Carlos Souza', color: '#33FFF6', active: true },
];

const EmployeeContext = createContext<EmployeeContextType | null>(null);

export function EmployeeProvider({ children }: { children: React.ReactNode }) {
  const [employees, setEmployees] = useState<Employee[]>(() => {
    const storedEmployees = storage.getEmployees();
    return storedEmployees.length > 0 ? storedEmployees : defaultEmployees;
  });

  useEffect(() => {
    storage.saveEmployees(employees);
  }, [employees]);

  const addEmployee = (employee: Omit<Employee, 'id'>) => {
    const newEmployee = { ...employee, id: Date.now().toString() };
    setEmployees(prev => [...prev, newEmployee]);
  };

  const removeEmployee = (id: string) => {
    setEmployees(prev => prev.filter(emp => emp.id !== id));
  };

  const toggleEmployeeStatus = (id: string) => {
    setEmployees(prev => prev.map(emp => 
      emp.id === id ? { ...emp, active: !emp.active } : emp
    ));
  };

  return (
    <EmployeeContext.Provider value={{ employees, addEmployee, removeEmployee, toggleEmployeeStatus }}>
      {children}
    </EmployeeContext.Provider>
  );
}

export const useEmployees = () => {
  const context = useContext(EmployeeContext);
  if (!context) {
    throw new Error('useEmployees deve ser usado dentro de um EmployeeProvider');
  }
  return context;
};