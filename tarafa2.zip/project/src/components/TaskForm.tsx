import React, { useState } from 'react';
import { useEmployees } from '../context/EmployeeContext';
import { PlusCircle } from 'lucide-react';
import { UrgencyLevel } from '../types';

interface TaskFormProps {
  onSubmit: (
    productName: string,
    quantity: number,
    assignedTo: string,
    deadline: string,
    urgency: UrgencyLevel
  ) => void;
}

export default function TaskForm({ onSubmit }: TaskFormProps) {
  const [productName, setProductName] = useState('');
  const [quantity, setQuantity] = useState('');
  const [assignedTo, setAssignedTo] = useState('');
  const [deadline, setDeadline] = useState('');
  const [urgency, setUrgency] = useState<UrgencyLevel>('normal');
  const { employees } = useEmployees();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (productName && quantity && assignedTo && deadline) {
      onSubmit(productName, Number(quantity), assignedTo, deadline, urgency);
      setProductName('');
      setQuantity('');
      setAssignedTo('');
      setDeadline('');
      setUrgency('normal');
    }
  };

  const getMinDateTime = () => {
    const now = new Date();
    return now.toISOString().slice(0, 16);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-lg shadow">
      <div className="flex items-center mb-4">
        <PlusCircle className="h-5 w-5 text-blue-500 mr-2" />
        <h2 className="text-lg font-semibold">Nova Tarefa</h2>
      </div>
      <div>
        <label htmlFor="product" className="block text-sm font-medium text-gray-700">
          Nome do Produto
        </label>
        <input
          type="text"
          id="product"
          required
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          value={productName}
          onChange={(e) => setProductName(e.target.value)}
        />
      </div>
      <div>
        <label htmlFor="quantity" className="block text-sm font-medium text-gray-700">
          Quantidade Necessária
        </label>
        <input
          type="number"
          id="quantity"
          required
          min="1"
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          value={quantity}
          onChange={(e) => setQuantity(e.target.value)}
        />
      </div>
      <div>
        <label htmlFor="deadline" className="block text-sm font-medium text-gray-700">
          Data e Hora de Entrega
        </label>
        <input
          type="datetime-local"
          id="deadline"
          required
          min={getMinDateTime()}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          value={deadline}
          onChange={(e) => setDeadline(e.target.value)}
        />
      </div>
      <div>
        <label htmlFor="urgency" className="block text-sm font-medium text-gray-700">
          Nível de Urgência
        </label>
        <select
          id="urgency"
          required
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          value={urgency}
          onChange={(e) => setUrgency(e.target.value as UrgencyLevel)}
        >
          <option value="very-urgent">Muito Urgente (30 minutos)</option>
          <option value="urgent">Urgente (1 hora)</option>
          <option value="normal">Normal (2 horas ou mais)</option>
        </select>
      </div>
      <div>
        <label htmlFor="assignedTo" className="block text-sm font-medium text-gray-700">
          Atribuir ao Funcionário
        </label>
        <select
          id="assignedTo"
          required
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          value={assignedTo}
          onChange={(e) => setAssignedTo(e.target.value)}
        >
          <option value="">Selecione um funcionário</option>
          {employees
            .filter(emp => emp.active)
            .map(employee => (
              <option key={employee.id} value={employee.id}>
                {employee.name}
              </option>
            ))}
        </select>
      </div>
      <button
        type="submit"
        className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
      >
        Adicionar Tarefa
      </button>
    </form>
  );
}