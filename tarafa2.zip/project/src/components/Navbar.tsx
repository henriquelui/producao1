import React from 'react';
import { useAuth } from '../context/AuthContext';
import { LogOut, LayoutDashboard, ClipboardList } from 'lucide-react';

export default function Navbar() {
  const { user, logout } = useAuth();

  return (
    <nav className="bg-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between h-16">
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <LayoutDashboard className="h-6 w-6 text-blue-500" />
              <span className="ml-2 text-xl font-semibold">Production System</span>
            </div>
            <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
              <a href="#" className="inline-flex items-center px-1 pt-1 text-gray-900">
                <ClipboardList className="h-5 w-5 mr-1" />
                Tasks
              </a>
            </div>
          </div>
          <div className="flex items-center">
            <span className="text-gray-700 mr-4">Welcome, {user?.username}</span>
            <button
              onClick={logout}
              className="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <LogOut className="h-4 w-4 mr-1" />
              Logout
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}